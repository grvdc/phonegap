/**
 * Created by vpatel on 7/14/2016.
 */
app.controller('captiveGameCtrl',['$scope', function($scope ) {
  
}])
