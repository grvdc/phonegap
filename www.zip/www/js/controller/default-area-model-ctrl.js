app.controller('defaultAreaModelController', function($scope,$ionicPopover,$ionicScrollDelegate){


  $scope.okDefaultAreaModel = function(){
      $scope.defaultAreaModal.remove();
    }

})
