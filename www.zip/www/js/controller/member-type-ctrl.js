/**
 * Created by vpatel on 7/4/2016.
 */
app.controller('memberTypeCtrl', function($scope) {

})
